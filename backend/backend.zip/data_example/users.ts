export const dataUsers = [
  {
    email: 'john.doe@example.com',
    password: 'P@ssw0rd123',
  },
  {
    email: 'jane.smith@example.com',
    password: 'MyP@ssw0rd',
  },
  {
    email: 'samuel.jackson@example.com',
    password: 'SecureP@ssword1',
  },
  {
    email: 'susan.adams@example.com',
    password: 'P@ssword321',
  },
  {
    email: 'david.brown@example.com',
    password: 'MyP@ssw0rd123',
  },
  {
    email: 'kate.johnson@example.com',
    password: 'P@ssword987',
  },
  {
    email: 'jimmy.nguyen@example.com',
    password: 'SecureP@ssword2',
  },
  {
    email: 'emily.harris@example.com',
    password: 'MyP@ssword456',
  },
  {
    email: 'william.taylor@example.com',
    password: 'P@ssword654',
  },
  {
    email: 'natalie.chen@example.com',
    password: 'SecureP@ssword3',
  },
];
